<?php include 'inc/header.php'; ?>

<?php
Session::checkSession();
?>

<div class="main">
<h1>Welcome to Online Exam - Start Here</h1>
	<div class="segment" style="margin-right:30px;">
		<img src="img/online_exam.png"/>
	</div>
	<div class="segment">
	<h2>Online Exam</h2>
        <p style="text-align: justify; display: block; font-size: 16px; color: #444444">Online examination is conducting a test online to measure the knowledge of the participants on a given topic.
            In the olden days everybody had to gather in a classroom at the same time to take an exam.
        For Online exam, you need a browser and the internet connection. It is a web based online examination solution
            for students, organizations, coaching institutes which can be customized as per the requirements.This management system provides
            simple and intuitive interface, a hassle-free flow from one test process to another.</p>
	<ul style="padding-top: 20px; padding-left: 50px;">
		<li><a href="start_test.php">Start Here...</a></li>
	</ul>
	</div>
	
  </div>
<?php include 'inc/footer.php'; ?>