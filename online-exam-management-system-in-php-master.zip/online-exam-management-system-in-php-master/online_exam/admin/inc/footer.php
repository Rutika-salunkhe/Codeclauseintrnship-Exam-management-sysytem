 </section>
<section class="footeroption">
		<h3><?php echo "Copyright @Online Exam Management"; ?></h3>
	</section>
</div>
</body>
</html>