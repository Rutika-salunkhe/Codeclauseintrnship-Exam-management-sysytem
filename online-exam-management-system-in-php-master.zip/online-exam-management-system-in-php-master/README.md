## Online Exam Management System using HTML, CSS, PHP OOPs, AJAX, jQuery, MYSQLi

- Report: https://sites.google.com/diu.edu.bd/onlineexam/

- Admin panel : 
Username = admin,
Password = 123
